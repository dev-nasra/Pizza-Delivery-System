# Resturant_Order_System

Restaurant Management System where the admin can view all orders. Customers can order and view their own past orders.
